import React from 'react';

function NotFound() {
    return (
        <div>That URL path was not found. Please check the path and try again.</div>
    )
}

export default NotFound;