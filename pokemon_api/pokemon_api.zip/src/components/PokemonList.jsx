import React, { useState, useEffect } from 'react';
import styles from './PokemonList.module.css';

function PokemonList() {
    const [pokemonList, setPokemonList] = useState([]);
    const [displayedList, setDisplayedList] = useState([]);

    useEffect(()=>{
        fetch('https://pokeapi.co/api/v2/pokemon/?limit=807')
        .then(response => response.json())
        .then(response => response.results)
        .then(response => setPokemonList(response))
        .catch(console.log)
    }, []);

    const displayList = () => {
        setDisplayedList(pokemonList);
    }

    const removeList = () => {
        setDisplayedList([]);
    }

    return (
        <div>
            <button onClick={displayList}>Fetch all Pokemon!</button>
            <button onClick={removeList}>Clear all Pokemon</button>
            <ul>
                {displayedList.map((pokemon, i) => {
                    return(
                        <li key={i}>{i+1}) {pokemon.name.charAt(0).toUpperCase() + pokemon.name.slice(1)}</li>
                    )
                })}
            </ul>
        </div>

    );
}

export default PokemonList;